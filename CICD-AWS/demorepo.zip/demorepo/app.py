import json
from tabulate import tabulate

def lambda_handler(event, context):
    # Ejemplo de datos
    data = [["Nombre", "Edad"], ["Michelle", 30], ["Bob", 25]]

    # Usar tabulate para formatear los datos en una tabla
    table = tabulate(data, headers='firstrow', tablefmt='grid')

    # Devolver la tabla como respuesta
    return {
        'statusCode': 200,
        'body': json.dumps(table)
    }
